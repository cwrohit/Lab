package feblab2;

import java.util.Scanner;

public class Swap_Two_Variable {
	public static void main(String[] args) {
		//x and y are to swap
		int x,y,temp;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		x = sc.nextInt();
		y = sc.nextInt();
		System.out.println("before swapping these no. are number:"+x+" "+y);
		//swapping
		//temp is used as a third variable to store the no.
		temp = x;
		x=y;
		y=temp;
		System.out.println("After swapping the no.:"+x+" "+y);
		
	
	}

}
