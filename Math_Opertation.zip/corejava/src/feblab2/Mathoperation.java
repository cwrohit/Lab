package feblab2;

import java.util.Scanner;
public class Mathoperation {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		int num1= sc.nextInt();
		System.out.println("Enter the second number");
		int num2 = sc.nextInt();
		//Addition operation
		int sum=num1+num2;
		System.out.println("Adding of two number is:"+sum);
		//SUbtract
		int Sub=num1-num2;
		System.out.println("Subtract of two number is:"+Sub);
		
		//Multiply
		int mul=num1*num2;
		System.out.println("multiply of two number is:"+mul);
		//divide
		int div=num1/num1;
		System.out.println("division of two number is:"+div);
		//remainder
		int mod=num1%num2;
		System.out.println("Reminder of two number is:"+mod);
		
	}
	

}
