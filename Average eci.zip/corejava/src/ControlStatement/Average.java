package ControlStatement;
import java.util.Scanner;
public class Average {
	public static void main(String[] args) {
		//taking the input from user
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the first number");
		int num1 = sc.nextInt();
		System.out.println("Enter the second number");
		int num2 = sc.nextInt();
		System.out.println("Enter the third number");
		int num3 = sc.nextInt();
		System.out.println("Enter the fourth number");
		int num4 = sc.nextInt();
		System.out.println("Enter the fifth number");
		int num5 = sc.nextInt();
		//calculate average of these number.
		int Average=(num1+num2+num3+num4+num5)/5;
		//print the average result
		System.out.println("Average of 5 no. is = "+Average);
		
	}

}
