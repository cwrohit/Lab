package feblab2;
import java.util.*;
class AdvancedAirthmetic{
	int divisorSum() {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the number");
		int number = sc.nextInt();
		int j=0;
		for(int i=1;i<=number;i++) {
			if (number %i==0) {
				System.out.println(""+i);
				j=j+i;
			}	
			}
		System.out.println("the sum of the dividors is:");
		System.out.println(j);
		return divisorSum();
		
		}
	
}

public class Myclaculator extends AdvancedAirthmetic{
	public static void main(String[] args) {
		//todo auto generate method stub
		AdvancedAirthmetic obj=new AdvancedAirthmetic();
		obj.divisorSum();
		
		
	}
	{
		
	}

}
