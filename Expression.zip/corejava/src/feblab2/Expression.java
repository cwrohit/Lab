package feblab2;

public class Expression {
	public static void main(String[] args) {
		//double data type we used in this to store the value
		double a=30.2,b=85.0,c=91.3,d=25.5;
		double result=((a*b-b*b)/(c-d));
		System.out.println("After solving the expression result is:"+result);
		
	}

}
